<h2> Erreur de page introuvable </h2>

<img src="images/erreur.jpeg" height="300" width="500">
<br>
<a href="index.php?page=1"> Revenir à l'accueil </a>
<br/>
<br/>
<br/>
